

Here is the explanation of what is included in the Supplementary file:


    1.networks.ipynb is a Python notebook that provides six different networks, including MLP, Convent, LeNet, AlexNet, VGG11, and ResNet-18. You will use this file to learn synthetic dates on the MNIST and CIFAR10 datasets.

    2.utils.ipynb is a Python notebook that provides utilities such as access to datasets, preprocessing, and data augmentation. You will use this file to learn synthetic dates on the MNIST and CIFAR10 datasets.

    3. Project_B_FAQs.pdf is a list of frequently asked questions that try to shed light on (almost) all of your questions and concerns that you may have during Project B.




